
# at home
# run:   %D as default directory
# put pyDAG in c:\python25 folder
loaded GE38_ARINC_BookAndPage_20081121.csv root= GE38_ARINC_BookAndPage_20081121 numLines= 181  extension= csv
181 lines.   Making substitutions... done
Writing output file GE38_ARINC_BookAndPage_20081121.xml
done


# TODO
1.)	Attributes for the NODE element don�t have quoted values
2.)	Attributes for the PARAMETERS element don�t have quoted values
3.)	SYS_TIME_MSB and SYS_TIME_LSB have descriptions with embedded quotes
4.)	Qgas_1 has a description larger than 40 characters
5.)	ALT is a duplicate name
6.)	TLS_SS is a duplicate name
7.)	NR is a duplicate name
8.)	T5 has a description larger than 40 characters
9.)	Some point names still have spaces which are not allowed
