# README.txt watermark.py

# Run this in folder with the pictures you want to watermark.
The watermark file must be there.   Use GIMP to create
a transparent background (delete the layer and type on
empty layer and save as png)


# Sample usage
watermark.py -w watermarkKPEr.png -t "scale"
