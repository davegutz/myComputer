from InFile import InFile
import StringSet
