from TextProcessing import *
from Dynamics import *
from Tables import *
from System import *
from Tkinter import *
